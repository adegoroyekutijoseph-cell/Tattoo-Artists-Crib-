import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import 'chat_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _query = TextEditingController();
  bool _busy = false;

  Future<void> _startChat(String otherUid, String otherName) async {
    setState(() => _busy = true);
    try {
      final me = FirebaseAuth.instance.currentUser!.uid;
      final members = [me, otherUid]..sort();
      final chatId = members.join('_');
      final ref = FirebaseFirestore.instance.collection('chats').doc(chatId);
      await ref.set({
        'members': members,
        'names': {me: 'You', otherUid: otherName},
        'lastMessage': '', 'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) =>
        ChatScreen(chatId: chatId, otherUid: otherUid, otherName: otherName)));
    } finally { if (mounted) setState(() => _busy = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Find people')),
    body: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
      TextField(controller: _query, decoration: InputDecoration(
        hintText: 'Search username (without @)', prefixIcon: const Icon(Icons.search),
        suffixIcon: IconButton(icon: const Icon(Icons.clear), onPressed: () => setState(() => _query.clear()))),
        onChanged: (_) => setState(() {})),
      const SizedBox(height: 12),
      Expanded(child: _query.text.trim().isEmpty
        ? const Center(child: Text('Type a username to find someone.'))
        : FutureBuilder<DocumentSnapshot>(
          future: FirebaseFirestore.instance.collection('usernames')
            .doc(_query.text.trim().replaceAll('@', '').toLowerCase()).get(),
          builder: (context, snap) {
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            if (!snap.data!.exists) return const Center(child: Text('No user found with that username.'));
            final uid = (snap.data!.data() as Map<String, dynamic>)['uid'] as String;
            if (uid == FirebaseAuth.instance.currentUser!.uid) return const Center(child: Text('That is your username.'));
            return FutureBuilder<DocumentSnapshot>(
              future: FirebaseFirestore.instance.collection('users').doc(uid).get(),
              builder: (context, userSnap) {
                if (!userSnap.hasData || !userSnap.data!.exists) return const Center(child: CircularProgressIndicator());
                final data = userSnap.data!.data() as Map<String, dynamic>;
                final name = data['displayName'] ?? data['username'] ?? 'Member';
                return ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.person)),
                  title: Text(name), subtitle: Text('@${data['username']}'),
                  trailing: _busy ? const CircularProgressIndicator() : const Icon(Icons.chat_bubble_outline),
                  onTap: _busy ? null : () => _startChat(uid, name),
                );
              },
            );
          },
        )),
    ])),
  );
}
