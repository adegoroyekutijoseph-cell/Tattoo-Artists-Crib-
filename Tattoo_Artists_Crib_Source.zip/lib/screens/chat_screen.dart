import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class ChatScreen extends StatefulWidget {
  final String chatId, otherUid, otherName;
  const ChatScreen({super.key, required this.chatId, required this.otherUid, required this.otherName});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _text = TextEditingController();
  bool _sending = false;

  Future<void> _send() async {
    final body = _text.text.trim();
    if (body.isEmpty || _sending) return;
    setState(() => _sending = true);
    _text.clear();
    try {
      final uid = FirebaseAuth.instance.currentUser!.uid;
      final chat = FirebaseFirestore.instance.collection('chats').doc(widget.chatId);
      await chat.collection('messages').add({
        'senderId': uid, 'text': body, 'type': 'text',
        'createdAt': FieldValue.serverTimestamp(),
      });
      await chat.set({
        'lastMessage': body, 'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    } catch (_) {
      _text.text = body;
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Message not sent. Check your connection and Firebase rules.')));
    } finally { if (mounted) setState(() => _sending = false); }
  }

  @override
  void dispose() { _text.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    return Scaffold(
      appBar: AppBar(title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(widget.otherName, style: const TextStyle(fontSize: 16)),
        const Text('Tattoo Artists Crib', style: TextStyle(fontSize: 11, color: Colors.white54)),
      ])),
      body: Column(children: [
        Expanded(child: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance.collection('chats').doc(widget.chatId)
            .collection('messages').orderBy('createdAt').snapshots(),
          builder: (context, snap) {
            if (snap.hasError) return const Center(child: Text('Could not load messages.'));
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            final docs = snap.data!.docs;
            if (docs.isEmpty) return const Center(child: Text('Say hello 👋'));
            return ListView.builder(padding: const EdgeInsets.all(12), itemCount: docs.length,
              itemBuilder: (context, i) {
                final m = docs[i].data() as Map<String, dynamic>;
                final mine = m['senderId'] == uid;
                final time = (m['createdAt'] as Timestamp?)?.toDate();
                return Align(alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .78),
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: mine ? const Color(0xFF8F2929) : const Color(0xFF252525),
                      borderRadius: BorderRadius.circular(16)),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                      Align(alignment: Alignment.centerLeft, child: Text(m['text'] ?? '')),
                      if (time != null) Text(DateFormat('HH:mm').format(time),
                        style: const TextStyle(fontSize: 10, color: Colors.white60)),
                    ]),
                  ),
                );
              });
          },
        )),
        SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
          child: Row(children: [
            Expanded(child: TextField(controller: _text, minLines: 1, maxLines: 4,
              textCapitalization: TextCapitalization.sentences,
              decoration: InputDecoration(hintText: 'Message...', contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(24))))),
            const SizedBox(width: 8),
            IconButton.filled(onPressed: _sending ? null : _send,
              icon: const Icon(Icons.send), style: IconButton.styleFrom(backgroundColor: const Color(0xFFE53935))),
          ]),
        )),
      ]),
    );
  }
}
