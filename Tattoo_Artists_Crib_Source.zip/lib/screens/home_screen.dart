import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'chat_screen.dart';
import 'search_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    return Scaffold(
      appBar: AppBar(
        title: const Text('TATTOO ARTISTS CRIB', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
        actions: [
          IconButton(tooltip: 'Find people', icon: const Icon(Icons.search),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SearchScreen()))),
          IconButton(tooltip: 'Log out', icon: const Icon(Icons.logout),
            onPressed: () => FirebaseAuth.instance.signOut()),
        ],
      ),
      body: Column(children: [
        Container(
          width: double.infinity, margin: const EdgeInsets.fromLTRB(16, 8, 16, 16),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: const Color(0xFF241414), borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFF6E2424))),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('YOUR PEOPLE. YOUR CRIB.', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFFF7770))),
            SizedBox(height: 5), Text('Find artists, connect and keep the conversation going.'),
          ]),
        ),
        const Padding(padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Align(alignment: Alignment.centerLeft, child: Text('YOUR CHATS', style: TextStyle(fontWeight: FontWeight.bold)))),
        Expanded(child: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance.collection('chats')
            .where('members', arrayContains: uid).orderBy('updatedAt', descending: true).snapshots(),
          builder: (context, snap) {
            if (snap.hasError) return const Center(child: Text('Could not load chats. Check Firestore setup.'));
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            final docs = snap.data!.docs;
            if (docs.isEmpty) return const Center(child: Text('No chats yet. Search for a username to start one.'));
            return ListView.builder(itemCount: docs.length, itemBuilder: (context, i) {
              final data = docs[i].data() as Map<String, dynamic>;
              final other = (data['members'] as List).firstWhere((m) => m != uid);
              final title = data['names']?[other] ?? 'Conversation';
              return ListTile(
                leading: const CircleAvatar(backgroundColor: Color(0xFF6E2424), child: Icon(Icons.person)),
                title: Text(title), subtitle: Text(data['lastMessage'] ?? 'Start chatting'),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) =>
                  ChatScreen(chatId: docs[i].id, otherUid: other, otherName: title))),
              );
            });
          },
        )),
      ]),
    );
  }
}
