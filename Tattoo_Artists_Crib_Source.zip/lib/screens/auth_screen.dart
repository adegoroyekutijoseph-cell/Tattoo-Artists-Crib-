import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _username = TextEditingController();
  final _phone = TextEditingController();
  final _otp = TextEditingController();
  bool _register = false, _busy = false, _otpSent = false;
  String? _verificationId;
  String? _error;

  Future<void> _run(Future<void> Function() action) async {
    setState(() { _busy = true; _error = null; });
    try { await action(); }
    on FirebaseAuthException catch (e) { setState(() => _error = e.message ?? e.code); }
    catch (e) { setState(() => _error = e.toString()); }
    finally { if (mounted) setState(() => _busy = false); }
  }

  Future<void> _emailAuth() => _run(() async {
    final auth = FirebaseAuth.instance;
    if (_register) {
      final raw = _username.text.trim().replaceAll('@', '').toLowerCase();
      if (!RegExp(r'^[a-z0-9_]{3,20}$').hasMatch(raw)) {
        throw Exception('Username must be 3–20 characters: letters, numbers or _.');
      }
      final userRef = FirebaseFirestore.instance.collection('usernames').doc(raw);
      final existing = await userRef.get();
      if (existing.exists) throw Exception('That username is already taken.');
      final cred = await auth.createUserWithEmailAndPassword(
        email: _email.text.trim(), password: _password.text);
      final uid = cred.user!.uid;
      await FirebaseFirestore.instance.collection('users').doc(uid).set({
        'uid': uid, 'username': raw, 'displayName': raw, 'email': _email.text.trim(),
        'phoneNumber': null, 'photoUrl': null, 'createdAt': FieldValue.serverTimestamp(),
        'lastSeen': FieldValue.serverTimestamp(), 'isOnline': true,
      });
      await userRef.set({'uid': uid});
    } else {
      await auth.signInWithEmailAndPassword(
        email: _email.text.trim(), password: _password.text);
    }
  });

  Future<void> _sendOtp() => _run(() async {
    final phone = _phone.text.trim();
    if (!phone.startsWith('+')) throw Exception('Enter phone with country code, e.g. +234...');
    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: phone,
      verificationCompleted: (credential) async {
        await FirebaseAuth.instance.currentUser?.linkWithCredential(credential);
      },
      verificationFailed: (e) => setState(() => _error = e.message ?? e.code),
      codeSent: (id, _) => setState(() { _verificationId = id; _otpSent = true; }),
      codeAutoRetrievalTimeout: (id) => _verificationId = id,
      timeout: const Duration(seconds: 60),
    );
  });

  Future<void> _verifyOtp() => _run(() async {
    if (_verificationId == null) throw Exception('Request a verification code first.');
    final credential = PhoneAuthProvider.credential(
      verificationId: _verificationId!, smsCode: _otp.text.trim());
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      await FirebaseAuth.instance.signInWithCredential(credential);
      final signedIn = FirebaseAuth.instance.currentUser!;
      final doc = FirebaseFirestore.instance.collection('users').doc(signedIn.uid);
      if (!(await doc.get()).exists) {
        final name = 'member_${const Uuid().v4().substring(0, 8)}';
        await doc.set({
          'uid': signedIn.uid, 'username': name, 'displayName': name,
          'email': null, 'phoneNumber': signedIn.phoneNumber,
          'photoUrl': null, 'createdAt': FieldValue.serverTimestamp(),
          'lastSeen': FieldValue.serverTimestamp(), 'isOnline': true,
        });
        await FirebaseFirestore.instance.collection('usernames').doc(name).set({'uid': signedIn.uid});
      }
    } else {
      await user.linkWithCredential(credential);
      await FirebaseFirestore.instance.collection('users').doc(user.uid)
        .set({'phoneNumber': user.phoneNumber}, SetOptions(merge: true));
    }
  });

  @override
  void dispose() {
    _email.dispose(); _password.dispose(); _username.dispose();
    _phone.dispose(); _otp.dispose(); super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 440),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Icon(Icons.bubble_chart, color: Color(0xFFE53935), size: 64),
          const SizedBox(height: 12),
          const Text('TATTOO ARTISTS CRIB', textAlign: TextAlign.center,
            style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
          const Text('Connect. Create. Talk.', textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white60)),
          const SizedBox(height: 30),
          SegmentedButton<bool>(
            segments: const [
              ButtonSegment(value: false, label: Text('Log in')),
              ButtonSegment(value: true, label: Text('Create account')),
            ],
            selected: {_register}, onSelectionChanged: (s) => setState(() {
              _register = s.first; _error = null;
            }),
          ),
          const SizedBox(height: 18),
          if (_register) ...[
            TextField(controller: _username, decoration: const InputDecoration(
              labelText: 'Choose username', prefixText: '@')),
            const SizedBox(height: 12),
          ],
          TextField(controller: _email, keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(labelText: 'Email address')),
          const SizedBox(height: 12),
          TextField(controller: _password, obscureText: true,
            decoration: const InputDecoration(labelText: 'Password')),
          const SizedBox(height: 14),
          ElevatedButton(onPressed: _busy ? null : _emailAuth,
            child: Text(_busy ? 'Please wait...' : (_register ? 'Create account with email' : 'Log in with email'))),
          const Padding(padding: EdgeInsets.symmetric(vertical: 18),
            child: Row(children: [Expanded(child: Divider()), Padding(
              padding: EdgeInsets.symmetric(horizontal: 12), child: Text('OR PHONE NUMBER')),
              Expanded(child: Divider())])),
          TextField(controller: _phone, keyboardType: TextInputType.phone,
            decoration: const InputDecoration(labelText: 'Phone number', hintText: '+234...')),
          const SizedBox(height: 10),
          if (_otpSent) ...[
            TextField(controller: _otp, keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: '6-digit verification code')),
            const SizedBox(height: 10),
            ElevatedButton(onPressed: _busy ? null : _verifyOtp,
              child: const Text('Verify code')),
          ] else ElevatedButton(onPressed: _busy ? null : _sendOtp,
            child: const Text('Send phone verification code')),
          if (_error != null) ...[
            const SizedBox(height: 14),
            Text(_error!, style: const TextStyle(color: Colors.redAccent)),
          ],
          const SizedBox(height: 20),
          const Text('By continuing, you agree to use the platform respectfully.',
            textAlign: TextAlign.center, style: TextStyle(color: Colors.white38, fontSize: 12)),
        ]),
      ),
    ))),
  );
}
