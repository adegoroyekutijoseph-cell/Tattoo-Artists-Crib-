# Tattoo Artists Crib

Android-first Flutter + Firebase messaging application source.

## Included in this first build
- Email/password registration and login.
- Phone OTP sign-in and phone linking for an already logged-in user.
- Username registration and username lookup.
- One-to-one real-time text chats backed by Cloud Firestore.
- Dark black/red interface.

## Important: connect Firebase before running
This is real application source, not a hosted service or a compiled APK. It needs your own Firebase project and Android app configuration.

1. Install Flutter SDK and Android Studio on a computer.
2. Create a Firebase project at https://console.firebase.google.com/
3. Add an Android app to Firebase. Use package ID `com.tattooartistscrib.app`.
4. In this project, run `flutterfire configure` and select your Firebase project. This generates `lib/firebase_options.dart`.
5. Update `lib/main.dart`: replace `Firebase.initializeApp()` with `Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform)` and add `import 'firebase_options.dart';`.
6. Enable Email/Password and Phone providers in Firebase Authentication.
7. Create a Cloud Firestore database. Start in production mode and apply the rules below.
8. Enable Firebase Storage if you later add photo/audio upload.
9. Run `flutter pub get`, then `flutter run`.

## Firestore security rules (starter rules)
Publish these rules in Firestore Rules. They restrict user documents and chat access to signed-in users and chat members. Review and strengthen before public launch.

```text
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function signedIn() { return request.auth != null; }
    function isMember(chatId) {
      return signedIn() &&
        request.auth.uid in get(/databases/$(database)/documents/chats/$(chatId)).data.members;
    }
    match /users/{uid} {
      allow read: if signedIn();
      allow create: if signedIn() && request.auth.uid == uid;
      allow update: if signedIn() && request.auth.uid == uid;
    }
    match /usernames/{username} {
      allow read: if signedIn();
      allow create: if signedIn() &&
        request.resource.data.uid == request.auth.uid;
      allow update, delete: if false;
    }
    match /chats/{chatId} {
      allow create: if signedIn() && request.auth.uid in request.resource.data.members;
      allow read, update: if isMember(chatId);
      match /messages/{messageId} {
        allow read: if isMember(chatId);
        allow create: if isMember(chatId) &&
          request.resource.data.senderId == request.auth.uid;
        allow update, delete: if false;
      }
    }
  }
}
```

## Notes
- Phone OTP delivery requires Firebase phone-auth setup, permitted regions, and billing/quotas where applicable.
- This first build intentionally focuses on secure account entry, username discovery, and reliable one-to-one text messaging. Media, voice notes, groups, presence, profile editing, push notifications, blocking/reporting, and production-grade abuse controls are next milestones.
- Never publish Firebase service-account credentials in the app.
